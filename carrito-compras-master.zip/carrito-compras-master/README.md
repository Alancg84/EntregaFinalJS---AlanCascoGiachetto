# carrito-compras
Carrito de compras hecho con HTML,Bootstrap y JavaScript

La idea fue hacer el front-end del mismo para una pagina web de un cliente.
No quise poner todos los productos en este ejemplo para no volver engorroso el codigo,
pero la idea principal es esa.
